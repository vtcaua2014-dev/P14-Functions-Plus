# P14 Functions+ — hospedagem gratuita

## Qual opção escolher?

- **Oracle Cloud Always Free (VPS):** melhor opção para tentar manter o bot 24/7 sem custo de computação, mas exige conta, configuração Linux/SSH e disponibilidade de recursos. A Oracle pode exigir cartão para validação, não garante capacidade em todas as regiões e os termos/limites podem mudar.
- **Render Free:** bom para testes, mas não é adequado para um bot Discord que precisa ficar online 24/7. Serviços web gratuitos entram em suspensão após 15 minutos sem tráfego HTTP/WebSocket; workers contínuos não têm plano Free.
- **Seu PC:** gratuito se já tiver o equipamento, mas só fica online enquanto o PC e a internet estiverem ligados.

## Deploy recomendado: Oracle Cloud (Ubuntu)

1. Crie uma conta em https://cloud.oracle.com/ e abra Compute → Instances → Create instance.
2. Escolha Ubuntu LTS e uma forma marcada explicitamente como **Always Free eligible**. Se não houver capacidade na região, tente outra região disponível na conta. Não escolha recurso pago.
3. Configure uma chave SSH e guarde a chave privada em local seguro. Não compartilhe a chave.
4. Conecte via SSH usando o IP público e a chave privada.
5. Instale ferramentas básicas:

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl git unzip build-essential python3
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
node -v
npm -v
```

6. Envie o ZIP para a VM via SCP/SFTP ou coloque o código em um repositório Git **sem segredos**. Na VM:

```bash
mkdir -p ~/p14 && cd ~/p14
unzip ~/P14-Functions-Plus-Safe.zip
cd VoltBot-main
npm ci
npm run build:dashboard
```

7. Configure o `.env` no diretório de instância que o projeto espera (`bots/instances/<nome>/.env`). Confira `INSTALL.md` e `.env.example`. Nunca publique `.env` no GitHub. Use o token criado em Discord Developer Portal → Bot, não token de conta pessoal.

8. Teste primeiro no terminal com `npm start`. Corrija qualquer erro de configuração antes de configurar o início automático.

9. Para reiniciar automaticamente, crie um serviço systemd. Ajuste `WorkingDirectory` e `ExecStart` para os caminhos reais do projeto:

```bash
sudo nano /etc/systemd/system/p14-functions-plus.service
```

Conteúdo de exemplo:

```ini
[Unit]
Description=P14 Functions Plus Discord Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/p14/VoltBot-main
ExecStart=/usr/bin/npm start
Restart=on-failure
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

Ative e confira:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now p14-functions-plus
sudo systemctl status p14-functions-plus
journalctl -u p14-functions-plus -f
```

## Segurança obrigatória

- Ative 2FA na conta Discord e no provedor de hospedagem.
- Use apenas o token de bot do Discord Developer Portal; nunca token de conta pessoal/self-bot.
- Não cole tokens em prints, chats, logs ou repositórios. Se vazarem, regenere-os imediatamente.
- Dê ao bot somente as permissões necessárias. Evite `Administrator` se não for essencial.
- Faça backup da pasta `data/` e proteja o dashboard com segredo forte e HTTPS antes de expô-lo publicamente.
- “Grátis para sempre” não é garantido: verifique as cotas e a elegibilidade Always Free antes de criar recursos.
