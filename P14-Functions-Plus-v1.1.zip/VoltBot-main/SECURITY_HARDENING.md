# P14 Functions+ / VoltBot — hardening notes

This modified archive removes the vanity URL auto-claim feature (`snipeurl`) because it accepted Discord user-account tokens and attempted actions with those tokens. Automating a normal user account is against Discord's rules and puts that account at risk. The bot no longer asks for, stores, decrypts, or uses a user token. On startup, legacy `vanity_snipers.userToken` values in an existing SQLite database are set to NULL.

## Before deploying

1. If you ever entered a Discord user token into the old command, change your Discord password and review active sessions; revoke suspicious sessions and enable MFA. Never share a user token or bot token.
2. If any real bot token or OAuth client secret was exposed in a repository, screenshots, or backups, regenerate it in the Discord Developer Portal.
3. Keep `.env` files and database files private. Set a long, random `JWT_SECRET` and `SPEED_PHRASE`; do not use defaults. Use HTTPS for a public dashboard.
4. Invite the bot with only the permissions it needs. Do not grant Administrator by default. Keep dashboard/owner access limited to trusted people.
5. Backup/restore, server backup, mass moderation, lockdown, and role-management commands can make destructive changes. They are not account-token stealers, but should remain restricted to trusted admins and tested on a private server first.

## Scope and limitation

This is a source-level hardening pass, not a guarantee that every dependency or every command is vulnerability-free. Review the code and keep dependencies updated before production use. The archive does not include your secrets or a configured Discord application token.
