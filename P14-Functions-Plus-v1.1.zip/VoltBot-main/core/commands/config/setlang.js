const { PermissionFlagsBits } = require("discord.js");
const { t } = require("../../utils/i18n");

module.exports = {
  name: "setlang",
  aliases: ["language", "langue", "idioma"],
  description:
    "Change la langue du bot pour le serveur / Change the bot language for the server",
  category: "config",
  usage: "+setlang [pt-BR/en]",
  userPerms: [PermissionFlagsBits.Administrator],
  botPerms: [],
  async execute(client, message, args) {
    const rawLangInput = args[0] ? args[0].toLowerCase() : null;
    const langInput = rawLangInput;
    const currentLang =
      client.db.getGuild(message.guild.id, "language") || "pt-BR";

    if (!langInput) {
      const embed = client.embedBuilder
        .info(client, message.t("commands.setlanguage.no_argument"))
        .setAuthor({
          name: message.t("commands.setlanguage.author_lang"),
          iconURL: client.user.displayAvatarURL(),
        })
        .setDescription(null)
        .addFields(
          {
            name: message.t("commands.setlanguage.field_current"),
            value: `\`${currentLang}\``,
            inline: true,
          },
          {
            name: message.t("commands.setlanguage.field_usage"),
            value: "`+setlang pt-BR`\n`+setlang en`",
            inline: true,
          },
        );
      return message.reply({ embeds: [embed] }).catch(() => {});
    }

    const normalizedLang = langInput === "pt" || langInput === "pt-br" ? "pt-BR" : langInput;
    if (!["pt-BR", "en"].includes(normalizedLang)) {
      return message
        .reply({
          embeds: [
            client.embedBuilder.error(
              client,
              message.t("commands.setlanguage.invalid_lang"),
            ),
          ],
        })
        .catch(() => {});
    }

    const selectedLang = normalizedLang;
    if (currentLang === selectedLang) {
      return message
        .reply({
          embeds: [
            client.embedBuilder.warning(
              client,
              message.t("commands.setlanguage.same_value"),
            ),
          ],
        })
        .catch(() => {});
    }

    client.db.updateGuild(message.guild.id, { language: selectedLang });

    const embed = client.embedBuilder
      .success(client, null)
      .setAuthor({
        name: message.t("commands.setlanguage.author_lang"),
        iconURL: client.user.displayAvatarURL(),
      })
      .setDescription(
        "```diff\n- " + currentLang + "\n+ " + langInput + "\n```",
      )
      .addFields({
        name: message.t("commands.setlanguage.field_note"),
        value: t(selectedLang, "commands.setlang.success"),
        inline: false,
      });
    return message.reply({ embeds: [embed] }).catch(() => {});
  },
};
