# Hospedar P14 Functions+ no Render pelo iPhone

## Importante
- O Render Free suspende Web Services após períodos sem tráfego; não garante bot Discord 24/7.
- Não envie tokens, arquivos `.env`, chaves SSH ou segredos ao GitHub.
- Este projeto usa SQLite e dependências nativas; a instalação pode falhar ou dados locais podem não persistir em reinicializações.

## Preparar o GitHub
1. Crie um repositório privado no GitHub.
2. Envie o conteúdo desta pasta (`VoltBot-main`) para a raiz do repositório.
3. Não envie `node_modules`, `bots/instances/*/.env` nem segredos.

## Criar o serviço
No Render, escolha **New + → Web Service** e conecte o repositório. Use:
- Runtime: Node
- Build Command: `npm install && npm run build:dashboard`
- Start Command: `mkdir -p bots/instances/p14 && cp /etc/secrets/p14.env bots/instances/p14/.env && npm start`
- Instance Type: Free para teste
- Root Directory: deixe vazio se `package.json` estiver na raiz do repositório; se o repositório contiver a pasta `VoltBot-main`, use `VoltBot-main`.

## Secret File
Em **Environment → Secret Files**, crie `p14.env` com este conteúdo e substitua todos os exemplos:

```dotenv
DISCORD_TOKEN=TOKEN_DO_BOT
BOT_ACCESS_ID=SEGREDO_ALEATORIO
OWNER_ID=SEU_ID_DISCORD
DISCORD_CLIENT_ID=ID_DA_APLICACAO
DISCORD_CLIENT_SECRET=SEGREDO_OAUTH2
JWT_SECRET=OUTRO_SEGREDO_ALEATORIO
PORT=3001
GUILD_ID=
DISCORD_REDIRECT_URI=https://SEU-SERVICO.onrender.com/api/auth/callback
DASHBOARD_URL=https://SEU-SERVICO.onrender.com
```

O `PORT=3001` dentro de `p14.env` é a porta da instância do bot. O Render fornece a variável `PORT` separada ao processo principal para o gateway HTTP. Depois que o Render fornecer a URL do serviço, atualize `DISCORD_REDIRECT_URI` e `DASHBOARD_URL` no Secret File e faça novo deploy.

## Segurança
- Gere valores aleatórios diferentes para `BOT_ACCESS_ID` e `JWT_SECRET`.
- O token Discord deve ser criado no Discord Developer Portal. Nunca use token de usuário.
- Se um segredo for exposto, revogue ou regenere-o imediatamente.

## Verificação
Veja **Logs** no Render. O gateway deve iniciar e a instância `p14` precisa carregar sem erros. Se aparecer erro, compartilhe apenas a mensagem de erro, nunca o conteúdo do Secret File.
